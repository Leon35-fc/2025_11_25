import { Alert } from 'react-bootstrap'

const Error = () => (
  <Alert variant="danger">Errore - Stai utilizzando il tuo Bearer token?</Alert>
)

export default Error
